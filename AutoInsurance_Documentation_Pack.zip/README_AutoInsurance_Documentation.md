# Auto Insurance Management Platform - Documentation & PlantUML

Prepared: 09 October 2026  |  Status: Draft for review

## Documents
- `01_Project_Charter.docx` - purpose, scope, stakeholders, risks and proposed milestones
- `02_SRS.docx` - functional/non-functional requirements and acceptance themes
- `03_API_Design.docx` - confirmed backend endpoints plus clearly labelled client-derived QuoteRating routes
- `04_Database_Design.docx` - database inventory, table groups and relationships
- `05_User_Journeys.docx` - journeys for Customer, Agent, Admin, Underwriter and Claims Officer
- `06_Technical_Implementation.docx` - layers, service calls, authentication, persistence and release gaps

## PlantUML source files
- `00-system-architecture.puml` - system component and data-store view
- `01` to `05` - one use-case diagram per role
- `10` to `17` - eight separate sequence diagrams
- `20` to `25` - separate ER diagrams for each service database/context

## Render a diagram
With PlantUML installed, run for example:

```bash
plantuml 00-system-architecture.puml
```

Repeat for each `.puml` file. For command-line PlantUML using a JAR:

```bash
java -jar plantuml.jar -tpng 00-system-architecture.puml
```

## Source limitations to keep visible
1. CustomerVehicleService.Infrastructure / its DbContext mappings and migrations were not supplied. Its ERD uses conceptual table names inferred from Domain entities and labels them accordingly.
2. QuoteRatingService.API, QuoteRatingService.Application and QuoteRating appsettings were not supplied. Quote/pricing routes listed in the API Design document are taken from the Angular service client and must be verified against backend controller attributes and DTOs.
3. IdentityService defines the role `Claims Adjuster`; ClaimsService controllers use `ClaimsOfficer`. Reconcile the JWT role value/authorization before treating the claims workflow as end-to-end ready.
4. The provided backend route dump exposes customer vehicle reads and an agent-side vehicle create route; confirm customer-side self-service expectations for vehicle and driver updates.
5. The provided payment entities record payment attempts and outcomes, but do not by themselves establish a live external payment-provider integration.

The documents describe source-visible behavior rather than asserting that all services compile, are deployed or have passed end-to-end tests.
